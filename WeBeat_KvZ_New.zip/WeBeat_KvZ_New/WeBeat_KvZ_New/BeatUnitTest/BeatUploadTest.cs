﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace BeatUnitTest
{
    class BeatUploadTest
    {
        Beat newbeat = new Beat();

        public void UploadBeatData(Beat beat)
        {
            
        }
    }
}
