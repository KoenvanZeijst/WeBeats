﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New_Core.BLL;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;
using WeBeat_KvZ_New_Core.DAL.MssqlContext;

namespace WeBeat_KvZ_New.Config
{
    public class AccountVerification
    {
        Customer account = new Customer();
        ICustomerContext icustomercontext;
        CustomerRepository customerrepo;

        private string con;

        public AccountVerification(string con)
        {
            this.con = con;
            icustomercontext = new CustomerMssqlContext(con);
            customerrepo = new CustomerRepository(icustomercontext);
        }

        public bool CheckIfLoggedIn(int? accountid)
        {
            if (accountid == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
