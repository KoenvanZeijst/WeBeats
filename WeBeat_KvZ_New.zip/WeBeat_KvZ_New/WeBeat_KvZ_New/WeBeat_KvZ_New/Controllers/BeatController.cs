﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New.Config;
using WeBeat_KvZ_New.Converters;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.BLL;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.MssqlContext;

namespace WeBeat_KvZ_New.Controllers
{
    public class BeatController : Controller
    {
        //account
        ICustomerContext icustomercontext;
        CustomerRepository customerrepository;
        CustomerConverter customerconverter = new CustomerConverter();

        //Beat
        IBeatContext ibeatcontext;
        BeatRepository beatrepository;
        BeatConverter beatconverter = new BeatConverter();
        BeatViewModel beatviewmodel = new BeatViewModel();

        //config
        AccountVerification accVeri;
        public IActionResult Index()
        {
            return View();
        }

       
        public BeatController(IConfiguration config)
        {
            string conn = config.GetSection("ConnectionStrings").GetSection("connectionstring").Value;
            ibeatcontext = new BeatMssqlContext(conn);
            beatrepository = new BeatRepository(ibeatcontext);
           
            icustomercontext = new CustomerMssqlContext(conn);
            customerrepository = new CustomerRepository(icustomercontext);

          

            accVeri = new AccountVerification(conn);
        }

        public IActionResult AddBeat(BeatDetailViewModel newbeat)
        {
            return RedirectToAction("Index", "Home");
        }
    }
}
