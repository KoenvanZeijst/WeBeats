﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using WeBeat_KvZ_New.Converters;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.BLL;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;
using WeBeat_KvZ_New_Core.DAL.MssqlContext;
using WeBeat_KvZ_New.Config;

namespace WeBeat_KvZ_New.Controllers
{
    public class CustomerController : Controller
    {
        //account
        ICustomerContext icustomercontext;
        CustomerRepository customerrepository;
        CustomerConverter customerconverter = new CustomerConverter();

        //Beat
        IBeatContext ibeatcontext;
        BeatRepository beatrepository;
        BeatConverter beatconverter = new BeatConverter();
        BeatViewModel beatviewmodel = new BeatViewModel();

        //config
        AccountVerification accVeri;
        public IActionResult Index()
        {
            return View();
        }

       [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            List<string> rolelist = new List<string>();

            rolelist.Add("Producer");
            rolelist.Add("Customer");


            ViewBag.CustomerRoles = rolelist;
            ViewData["Message"] = "Make an account";

            return View();
        }
        public CustomerController(IConfiguration config)
        {
            string conn = config.GetSection("ConnectionStrings").GetSection("connectionstring").Value;
            icustomercontext = new CustomerMssqlContext(conn);
            customerrepository = new CustomerRepository(icustomercontext);
            ibeatcontext = new BeatMssqlContext(conn);
            beatrepository = new BeatRepository(ibeatcontext);




            accVeri = new AccountVerification(conn);
        }

        [HttpPost]
        public async Task<IActionResult> Register(CustomerDetailViewModel viewmodel, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            Customer add = customerconverter.ViewModelToCustomer(viewmodel);



            if (customerrepository.Register(add) == true)
            {
                return View("~/Views/Home/Login.cshtml");
            }
            else
            {
                // return register screen
                return View("~/Views/Customer/Register.cshtml");
            }
        }

        [HttpPost]
        public IActionResult Login(CustomerDetailViewModel viewmodel, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            Customer inserted = customerconverter.ViewModelToCustomer(viewmodel);
            Customer retrieved = customerrepository.Login(inserted);
            //beatviewmodel.beats = new List<BeatDetailViewModel>();

            if (retrieved.Email == inserted.Email)
            {
                HttpContext.Session.SetInt32("UserID", retrieved.UserId);
                if (customerrepository.CheckRoleID(HttpContext.Session.GetInt32("UserID")) == 2)
                {
                    HttpContext.Session.SetInt32("Producer", 1);
                }
                else if (customerrepository.CheckRoleID(HttpContext.Session.GetInt32("UserID")) == 3)
                {
                    HttpContext.Session.SetInt32("Admin", 1);
                }

                return View("~/Views/Home/Index.cshtml", beatviewmodel);//
            }
            else
            {
                return View("~/Views/Customer/Login.cshtml");
            }
        }
    }
}