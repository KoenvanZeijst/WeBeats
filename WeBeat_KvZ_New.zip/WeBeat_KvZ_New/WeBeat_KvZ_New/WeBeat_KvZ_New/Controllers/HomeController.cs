﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using WeBeat_KvZ_New.Config;
using WeBeat_KvZ_New.Converters;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.BLL;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;
using WeBeat_KvZ_New_Core.DAL.MssqlContext;
using Microsoft.AspNetCore.Http;

namespace WeBeat_KvZ_New.Controllers
{
    public class HomeController : Controller
    {
        //account
        ICustomerContext icustomercontext;
        CustomerRepository customerrepository;
        CustomerConverter customerconverter = new CustomerConverter();

        //Beat
        IBeatContext ibeatcontext;
        BeatRepository beatrepository;
        BeatConverter beatconverter = new BeatConverter();
        BeatViewModel beatviewmodel = new BeatViewModel();

        AccountVerification accVeri;

        public HomeController(IConfiguration iconfiguration)
        {
            string conn = iconfiguration.GetSection("ConnectionStrings").GetSection("connectionstring").Value;
            icustomercontext = new CustomerMssqlContext(conn);
            customerrepository = new CustomerRepository(icustomercontext);

            ibeatcontext = new BeatMssqlContext(conn);
            beatrepository = new BeatRepository(ibeatcontext);

            accVeri = new AccountVerification(conn);
        }
        public IActionResult Index()
        {

            if (accVeri.CheckIfLoggedIn(HttpContext.Session.GetInt32("UserId")) == false)
            {
                return View();
            }
            Customer loggedin = new Customer();
            loggedin.UserId = (int)HttpContext.Session.GetInt32("UserId");

            if (HttpContext.Session.GetInt32("Customer") != 1 && HttpContext.Session.GetInt32("Admin") != 1)
            {
                List<Beat> beat = beatrepository.GetBeatsByProducerId(loggedin.UserId);
                ViewBag.Beats = beat;
                return View("~/Views/Home/Index.cshtml",beat);
            }
            else
            {
                return View();
            }
            
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Login()
        {

            return RedirectToAction("Login", "Customer");
        }

        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
