﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New.Converters
{
    public class BeatConverter
    {
        public Beat ViewModelToBeat(BeatDetailViewModel BDVM)
        {
            CustomerConverter c = new CustomerConverter();
            Beat beat = new Beat()
            {

                Id = BDVM.Id,
                Producer = BDVM.Producer,
                BeatName = BDVM.BeatName,

                Price = BDVM.Price,
                Genre = BDVM.Genre,

            };
            return beat;
        }

        public BeatDetailViewModel ViewModelFromBeat(Beat beat)
        {
            BeatDetailViewModel BDVM = new BeatDetailViewModel()
            {
                Id = beat.Id,
                Producer = beat.Producer,
                BeatName = beat.BeatName,

                Price = beat.Price,
                Genre = beat.Genre,
            };

            return BDVM;
        }
    }
}
