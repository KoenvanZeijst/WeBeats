﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New.Converters
{
    public class CustomerConverter
    {
        public Customer ViewModelToCustomer(CustomerDetailViewModel CDVM)
        {
            Customer cust = new Customer()
            {
                UserId = CDVM.UserId,
                RoleId = CDVM.RoleId,
                Name = CDVM.Name,
                DateOfBirth = CDVM.DateOfBirth,
                Email = CDVM.Email,
                Password = CDVM.Password

            };
            return cust;
        }

        public CustomerDetailViewModel ViewModelFromCustomer(Customer cust)
        {
            CustomerDetailViewModel CDVM = new CustomerDetailViewModel()
            {
                UserId = cust.UserId,
                RoleId = cust.RoleId,
                Name = cust.Name,
                DateOfBirth = cust.DateOfBirth,
                Email = cust.Email,
                Password = cust.Password
            };
            return CDVM;
        }
    }
}
