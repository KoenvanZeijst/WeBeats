﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New.Converters
{
    public class OrderConverter
    {
        public Order ViewModelToOrder(OrderDetailViewModel ODVM)
        {
            Order order = new Order()
            {

                Id = ODVM.Id,
                Customer = ODVM.Customer,
                Orderline = ODVM.Orderline,
                Beat = ODVM.Beat,
                Quantity = ODVM.Quantity,
              

            };
            return order;
        }

        public OrderDetailViewModel ViewModelFromOrder(Order order)
        {
           OrderDetailViewModel ODVM = new OrderDetailViewModel()
            {
               Id = order.Id,
               Customer = order.Customer,
               Orderline = order.Orderline,
               Beat = order.Beat,
               Quantity = order.Quantity,
           };

            return ODVM;
        }
    }
}
