﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New.Models;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New.Converters
{
    public class OrderLineConverter
    {
        public Orderline ViewModelToOrder(OrderLineDetailViewModel OLDVM)
        {
            Orderline order = new Orderline()
            {

                Id = OLDVM.Id,
                Beat = OLDVM.Beat,
               
                Quantity = OLDVM.Quantity,


            };
            return order;
        }

        public OrderLineDetailViewModel ViewModelFromOrder(Orderline orderline)
        {
            OrderLineDetailViewModel OLDVM = new OrderLineDetailViewModel()
            {
                Id = orderline.Id,
                Beat = orderline.Beat,

                Quantity = orderline.Quantity,

            };

            return OLDVM;
        }
    }
}
