﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New.Models
{
    public class BeatDetailViewModel
    {
        public int Id { get; set; }

        public Customer Producer { get; set; }

        public string BeatName { get; set; }

        public DateTime Duration { get; set; }

        public double Price { get; set; }

        public string Genre { get; set; }
    }
}
