﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeBeat_KvZ_New.Models
{
    public class BeatViewModel
    {
        public List<BeatViewModel> beats;
    }
}
