﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.BLL
{
    public class BeatRepository
    {
        IBeatContext Context;

        public BeatRepository(IBeatContext context)
        {
            Context = context;
        }

        public Beat GetBeatById(int id)
        {
            return Context.GetBeatById(id);
        }

        public List<Beat> GetAllBeats()
        {
            return Context.GetAllBeats();
        }

        public bool InsertBeat(Beat b)
        {
            return Context.InsertBeat(b);
        }

        public List<Beat> GetBeatsByProducerId(int producerid)
        {
            return Context.GetBeatsByProducerId(producerid);
        }
    }
}
