﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.BLL
{
    public  class CustomerRepository
    {
        private ICustomerContext Context;

        public CustomerRepository(ICustomerContext context)
        {
            Context = context;
        }

        public Customer Login(Customer account)
        {
            return Context.Login(account);
        }

        public List<Customer> GetAllCustomers()
        {
            return Context.GetAllCustomers();
        }

        public bool Register(Customer account)
        {
            return Context.Register(account);
        }

        public int CheckRoleID(int? customerid)
        {
            return Context.CheckRoleID(customerid);
        }
    }
}
