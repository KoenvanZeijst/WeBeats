﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.BLL
{
    public class OrderRepository
    {
        private IOrderContext Context;

        public OrderRepository(IOrderContext context)
        {
            Context = context;
        }

        public List<Order> GetAllOrders()
        {
            return Context.GetAllOrders();
        }
    }
}
