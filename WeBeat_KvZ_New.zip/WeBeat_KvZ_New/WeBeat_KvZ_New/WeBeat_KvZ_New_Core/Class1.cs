﻿using System;

namespace WeBeat_KvZ_New_Core
{
    public class Class1
    {
    }
}
