﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.DAL.Context
{
    public interface IBeatContext
    {
        bool InsertBeat(Beat file);

        Beat GetBeatById(int id);

        List<Beat> GetAllBeats();

        List<Beat> GetBeatsByProducerId(int producerid);
    }
}
