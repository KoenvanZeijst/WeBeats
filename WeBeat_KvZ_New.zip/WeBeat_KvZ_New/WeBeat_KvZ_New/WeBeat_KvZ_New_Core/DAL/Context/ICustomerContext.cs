﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.DAL.Context
{
    public interface ICustomerContext
    {
        Customer Login(Customer account);

        bool Register(Customer account);

        List<Customer> GetAllCustomers();

        int CheckRoleID(int? userid);
    }
}
