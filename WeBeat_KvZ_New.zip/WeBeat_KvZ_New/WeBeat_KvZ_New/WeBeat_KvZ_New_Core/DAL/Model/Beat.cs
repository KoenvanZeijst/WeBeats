﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeBeat_KvZ_New_Core.DAL.Model
{
    public class Beat
    {
        public int Id { get; set; }

        public Customer Producer { get; set; }

        public string BeatName { get; set; }

        public double Price { get; set; }

        public string Genre { get; set; }

        public byte Data { get; set; }

      
    }
}
