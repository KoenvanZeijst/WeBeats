﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeBeat_KvZ_New_Core.DAL.Model
{
    public class Customer
    {
        public int UserId { get; set; }

        public int RoleId { get; set; }
        public string Name { get; set; }

        public DateTime DateOfBirth { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public Customer()
        {

        }

        public Customer(int id, int roleid, string name, DateTime birthdate, string email, string password)
        {
            this.UserId = id;
            this.RoleId = roleid;
            this.Name = name;
            this.DateOfBirth = birthdate;
            this.Email = email;
            this.Password = password;
        }

        public Customer(int id, int roleid)
        {
            this.UserId = id;
            this.RoleId = roleid;
        }
    }
}
