﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeBeat_KvZ_New_Core.DAL.Model
{
    public class DataSetParser
    {
    }
}
