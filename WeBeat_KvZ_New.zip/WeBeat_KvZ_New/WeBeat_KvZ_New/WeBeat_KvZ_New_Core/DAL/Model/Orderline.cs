﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeBeat_KvZ_New_Core.DAL.Model
{
   public class Orderline
    {
        public int Id { get; set; }
        public Beat Beat { get; set; }
        public int Quantity { get; set; }
    }
}
