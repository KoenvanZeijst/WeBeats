﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Model;
using System.Data;
using System.Data.SqlClient;
using WeBeat_KvZ_New_Core.DAL.Context;

namespace WeBeat_KvZ_New_Core.DAL.MssqlContext
{
    public class BeatMssqlContext: IBeatContext
    {
        private string con;

        //B Beat Upload
        public BeatMssqlContext(string conn)
        {
            this.con = conn;
        }

        public bool InsertBeat(Beat beat)
        {
            try
            {
                SqlConnection connection = new SqlConnection(con);
                using (connection)
                {
                    SqlCommand command = new SqlCommand("insert into Beat " +
                        "(BeatID, ProducerID, BeatName, Price, Genre)" +
                        " values (@BeatID,@ProducerID,@BeatName,@Price, @genre)", connection);
                    command.Parameters.AddWithValue("BeatID", beat.Id);
                    command.Parameters.AddWithValue("ProducerID", beat.Producer.UserId);
                    command.Parameters.AddWithValue("BeatName", beat.BeatName);
                    command.Parameters.AddWithValue("Price", beat.Price);
                    command.Parameters.AddWithValue("Genre", beat.Genre);
                    connection.Open();
                    command.ExecuteNonQuery();

                    SqlCommand UploadCommand = new SqlCommand("insert into BeatMap "
                        + "(BeatID, Data)" + "values(@BeatID,@Data)", connection);
                    UploadCommand.Parameters.AddWithValue("BeatID", beat.Id);
                    UploadCommand.Parameters.AddWithValue("Data", beat.Data);
                    UploadCommand.ExecuteNonQuery();

                    return true;
                }
            }
            catch
            {
                return false;
            }

        }



        public Beat GetBeatById(int id)
        {

            SqlConnection connection = new SqlConnection(con);

            return null;

        }
        // beats van producer ophalen
        public List<Beat> GetBeatsByProducerId(int producerid)
        {

            SqlConnection connection = new SqlConnection(con);
            List<Beat> ProducerBeats = new List<Beat>();
            using (connection)
            {
                SqlCommand command = new SqlCommand("Select * from Beat where ProducerID = @ProducerID", connection);
                command.Parameters.AddWithValue("@ProducerID", producerid);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        while (reader.Read())
                        {
                            Beat beat = new Beat();

                            beat.Producer.UserId = Convert.ToInt32(reader["ProducerID"]);
                            beat.BeatName = Convert.ToString(reader["BeatName"]);

                            beat.Price = Convert.ToDouble(reader["Price"]);
                            beat.Genre = Convert.ToString(reader["Genre"]);
                            ProducerBeats.Add(beat);
                        }
                    }
                    catch
                    {

                    }
                }
                return ProducerBeats;

            }


        }

        // selecteer alle beats
        public List<Beat> GetAllBeats()
        {
            List<Beat> beats = new List<Beat>();
            SqlConnection connection = new SqlConnection(con);
            string query = "select * from Beat";
            SqlCommand sqlCommand = new SqlCommand(query, connection);
            connection.Open();
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
                while (reader.Read())
                {
                    Beat beat = new Beat();
                    // beat.Id = Convert.ToInt32(reader["BeatID"]);
                    beat.Producer.UserId = Convert.ToInt32(reader["ProducerId"]);
                    beat.BeatName = Convert.ToString(reader["BeatName"]);

                    beat.Price = Convert.ToDouble(reader["Price"]);
                    beat.Genre = Convert.ToString(reader["Genre"]);
                    beats.Add(beat);
                }
            }
            return beats;
        }
    }
}
