﻿using System;
using System.Collections.Generic;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;
using System.Data.SqlClient;
using System.Data;

namespace WeBeat_KvZ_New_Core.DAL.MssqlContext
{
   public class CustomerMssqlContext: ICustomerContext
    {
        private string con;
        public CustomerMssqlContext(string conn)
        {
            this.con = conn;
        }
        public List<Customer> GetAllCustomers()
        {
            List<Customer> customers = new List<Customer>();
            SqlConnection connection = new SqlConnection(con);
            using (connection)
            {
                SqlCommand command = new SqlCommand("Select * from [User]", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        Customer customer = new Customer();

                        customer.UserId = Convert.ToInt32(reader["ProducerID"]);
                        customer.Name = Convert.ToString(reader["BeatName"]);
                        customers.Add(customer);
                    }
                    catch
                    {

                    }
                }

            }
                return customers;
        }

        //inloggen gebruiker
        public Customer Login(Customer customer)
        {
            SqlConnection connection = new SqlConnection(con);
            using (connection)
            {
                SqlCommand command = new SqlCommand("select UserID, RoleID from [User] where eMail = @eMail and Password = @Password", connection);
                command.Parameters.AddWithValue("@eMail", customer.Email);
                command.Parameters.AddWithValue("@Password", customer.Password);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        
                        while (reader.Read())
                        {
                            customer.RoleId = Convert.ToInt32(reader["RoleID"]);
                            customer.UserId = Convert.ToInt32(reader["UserID"]);
                            //LoggedIn = new Customer(userId, roleId);
                        }
                        
                    }
                    catch
                    {
                        Console.WriteLine("No rows found.");

                    }


                }
            }
            connection.Close();
            return customer;

        }

        public int CheckRoleID(int? userid)
        {
            int id = 0;
            SqlConnection connection = new SqlConnection(con);
            using (connection)
            {
                SqlCommand command = new SqlCommand("SELECT User.RoleID FROM [User] WHERE UserID = @UserID", connection);
                command.Parameters.AddWithValue("@UserID", userid);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        while (reader.Read())
                        {
                            id = Convert.ToInt32(reader["RoleID"]);
                        }
                    }
                    catch
                    {
                        Console.WriteLine("No rows found.");
                    }
                }
            }
            connection.Close();
            return id;
        }
        //registreren gebruiker
        public bool Register(Customer customer)
        {
            try
            {
                SqlConnection connection = new SqlConnection(con);
                using (connection)
                {
                    SqlCommand command = new SqlCommand("insert into [User] (UserID, RoleID, Name, Birthdate, eMail, Password) values (@UserID,@RoleId,@Name,@Birthdate,@eMail,@Password)", connection);
                    command.Parameters.AddWithValue("UserID", customer.UserId);
                    command.Parameters.AddWithValue("RoleID", customer.RoleId);
                    command.Parameters.AddWithValue("Name", customer.Name);
                    command.Parameters.AddWithValue("Birthdate", customer.DateOfBirth);
                    command.Parameters.AddWithValue("eMail", customer.Email);
                    command.Parameters.AddWithValue("Password", customer.Password);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    return true;

                }
            }
            catch
            {
                return false;
            }

        }
    }
}
