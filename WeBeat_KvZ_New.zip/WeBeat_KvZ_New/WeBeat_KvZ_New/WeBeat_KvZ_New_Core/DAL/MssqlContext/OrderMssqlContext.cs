﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using WeBeat_KvZ_New_Core.DAL.Context;
using WeBeat_KvZ_New_Core.DAL.Model;

namespace WeBeat_KvZ_New_Core.DAL.MssqlContext
{
    public class OrderMssqlContext: IOrderContext
    {
        private string con;

        //B Beat Upload
        public OrderMssqlContext(string conn)
        {
            this.con = conn;
        }

        public List<Order> GetAllOrders()
        {
            List<Order> orders = new List<Order>();
            SqlConnection connection = new SqlConnection(con);
            using (connection)
            {
                SqlCommand command = new SqlCommand("Select * from Order", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    try
                    {
                        Order order = new Order();

                        order.Customer.UserId = Convert.ToInt32(reader["UserID"]);
                        order.Beat.Id = Convert.ToInt32(reader["BeatID"]);
                        orders.Add(order);
                    }
                    catch
                    {

                    }
                }

            }
            return orders;
        }

    }
}
